package com.lara;

public class Manager3
{
	public static void main(String[] args) 
	throws Exception
	{
		int results = MasterDataDao.storeMaterData("D:\\LARA_Second_15_January_2017\\10_to_12_batch\\Core_jdbcproject\\project1\\project1\\src\\com\\lara\\data.xlsx", 
													"genders", "gender");
		System.out.println(results);
		results = MasterDataDao.storeMaterData("D:\\LARA_Second_15_January_2017\\10_to_12_batch\\Core_jdbcproject\\project1\\project1\\src\\com\\lara\\data.xlsx", 
				   							   "skills", "skill");
		System.out.println(results);
		results = MasterDataDao.storeMaterData("D:\\LARA_Second_15_January_2017\\10_to_12_batch\\Core_jdbcproject\\project1\\project1\\src\\com\\lara\\data.xlsx", 
				   							   "educations", "education");
		System.out.println(results);		
	}
}
/*
2
4
4
*/