package com.lara;
import java.io.File;
import java.io.FileOutputStream;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class Manager2
{
	public static void main(String[] args)
	throws Exception
	{
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Sample_sheet");
		Row row = sheet.createRow(0);
		Cell cell = row.createCell(0);
		cell.setCellValue("Sno");
		Cell cell1 = row.createCell(1);
		cell1.setCellValue("Name");
		Cell cell2 = row.createCell(2);
		cell2.setCellValue("Age");
		Row row1 = sheet.createRow(1);
		Cell cell21 = row1.createCell(0);
		cell21.setCellValue("1");
		Cell cell22 = row1.createCell(1);
		cell22.setCellValue("Ramu");
		Cell cell23 = row1.createCell(2);
		cell23.setCellValue("22");
		File f1 = new File("D:\\test2.xlsx");
		FileOutputStream out = new FileOutputStream(f1);
		workbook.write(out);
		out.close();		
		System.out.println("done");
	}
}	
