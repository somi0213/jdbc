package com.lara;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class MasterDataDao 
{
	private static XSSFSheet getSheet(String fileName,
									  String sheetName)
		throws Exception
	{
		File f1 = new File(fileName);
		FileInputStream file = new FileInputStream(f1);
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheet(sheetName);
		return sheet;
	}
	public static int storeMaterData(String fileName,
								   String sheetName,
								   String tableName)
		throws Exception
	{
		int records = 0;
		XSSFSheet sheet = getSheet(fileName, sheetName);
		String sql = null;
		Iterator<Row> rowIterator = sheet.iterator();
		Row row = null;
		String id, name;
		try(Connection con = Util.getConnection();
			Statement stmt = con.createStatement())
		{
			while(rowIterator.hasNext())
			{
				row = rowIterator.next();
				id = row.getCell(0).toString();
				name = row.getCell(1).toString();
				sql = "INSERT INTO " + tableName + " VALUES(" + id + ",'" + name +"')";
				records += stmt.executeUpdate(sql);
			}	
		}
		catch(SQLException ex)
		{
			ex.printStackTrace();
		}
		return records;
	}
}
