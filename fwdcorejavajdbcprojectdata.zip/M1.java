package com.lara;
import java.io.File;
import java.io.FileOutputStream;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class M1 {
	public static void main(String[] args) throws Exception {
		XSSFWorkbook workbook = new XSSFWorkbook(); // object of worksheet, u can supply any name, u can take this as a excel file 
		XSSFSheet sheet = workbook.createSheet("Sample_sheet");// under 1 workbook , 1 sheet
		
		Row row0 = sheet.createRow(0); // in that sheet 1st row
		Cell cell00 = row0.createCell(0);// then in that row 1 cell
		cell00.setCellValue("Sno");
		Cell cell01 = row0.createCell(1);
		cell01.setCellValue("Name");
		Cell cell02 = row0.createCell(2);
		cell02.setCellValue("Age");
		
		Row row1 = sheet.createRow(1);
		Cell cell10 = row1.createCell(0);
		cell10.setCellValue("1");
		Cell cell11 = row1.createCell(1);
		cell11.setCellValue("Ramu");
		Cell cell12 = row1.createCell(2);
		cell12.setCellValue("22");
		
		File f1 = new File("test1.xlsx");
		FileOutputStream out = new FileOutputStream(f1);
		workbook.write(out);// here its like opposite, generally we write out.write(obj) but here ulta
		out.close();
		System.out.println("done");
	}
}
/*
done
___________________
Refresh the file
Its a very rare requirnment of writing anything into a excel sheet 
so know need to remember anything here
*/