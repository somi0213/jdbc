package com.lara;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class Util 
{
	private static String driverClassName;
	private static String url;
	private static String username;
	private static String password;
	
	static
	{
		Properties pr = new Properties();
		try(FileReader fin = new FileReader("db.properties"))
		{
			pr.load(fin);
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
		driverClassName = pr.getProperty("driverClassName");
		url = pr.getProperty("url");
		username = pr.getProperty("username");
		password = pr.getProperty("password");
	}
	
	static
	{
		try
		{
			Class.forName(driverClassName);
		}
		catch(ClassNotFoundException ex)
		{
			ex.printStackTrace();
		}
	}
	
	public static Connection getConnection() throws SQLException
	{
		Connection con = DriverManager.getConnection(url, 
													 username, 
													 password);
		return con;
	}
	
	
}
